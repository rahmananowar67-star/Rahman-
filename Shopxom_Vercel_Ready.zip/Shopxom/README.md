# Shopxom — Seller Studio (Frontend Demo)

A responsive, Vercel-ready static frontend built with HTML, CSS and vanilla JavaScript.

## Files
- `index.html` — page structure
- `style.css` — responsive visual design
- `script.js` — navigation, product/order/customer/coupon actions and local demo storage

## Run locally
Open `index.html` in a modern browser. No build step or package installation is required.

## Deploy to Vercel
1. Create a folder/repository containing these three files.
2. Import the repository into Vercel, or upload the project using a supported Vercel workflow.
3. Choose **Other** / static site if asked for a framework.
4. Leave Build Command empty and Output Directory as `.` (project root).
5. Deploy.

## Demo features
- Dashboard and summary cards
- Add/edit/delete products; search and stock filters
- Order list and status updates
- Customer list
- Storefront preview
- WhatsApp order handoff (set your WhatsApp number in Settings, including country code, digits only)
- Coupon creation and pause/activate
- Local analytics summary
- Store settings and JSON export
- Responsive mobile sidebar

## Important limitations
This is a frontend prototype, not a production multi-vendor commerce backend. Demo records are saved in the current browser using `localStorage`; they are not shared across devices or users and can be cleared by the browser. Do not store passwords, payment information, or sensitive customer data here.

Before a public commercial launch, add a secure backend/database, authentication, seller-level data isolation, server-side authorization, payment gateway integration, order persistence, validation, backups, privacy/terms pages, and admin security. WhatsApp handoff opens a prefilled message; it does not itself verify payment or confirm fulfilment.

No Firebase or Supabase SDK is included in this version.
